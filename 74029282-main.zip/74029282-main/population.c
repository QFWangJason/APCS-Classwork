#include <stido.h>
#include <cs50.h>
#include <math.h>

int initial;
int 

int main(){

}