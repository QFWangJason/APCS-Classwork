#include <stdio.h>
#include <cs50.h>
//Prompt "What is your name", getting a string called "name"
//Output Hello, (name) using printf()
int main(void)
{
    string name = get_string("What's your name? ");
    printf("Hello, %s\n", name);
}